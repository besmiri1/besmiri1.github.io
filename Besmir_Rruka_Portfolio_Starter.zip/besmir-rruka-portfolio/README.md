# Besmir Rruka — Portfolio starter

A responsive personal portfolio built with plain HTML, CSS and JavaScript.

## 1. Personalize before publishing
- Search for `YOUR-GITHUB-USERNAME` in `index.html` and replace it with your real GitHub username.
- Check that the LinkedIn URL in `index.html` opens your own profile.
- Replace the three sample project cards with your real projects.
- Add screenshots to a folder such as `assets/` and link them from the project cards if useful.
- If you want a CV button, put your PDF in this folder and name it `cv.pdf`. Otherwise remove the button.
- Add a contact email only if you want it public.

## 2. Preview on your computer
Open `index.html` in your browser. For local development, VS Code with the Live Server extension is convenient but not required.

## 3. Publish with GitHub Pages
1. Create or sign in to a GitHub account at https://github.com.
2. Create a **public** repository named exactly `YOUR-GITHUB-USERNAME.github.io` (replace with your username).
3. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the root of the repository.
4. Open the repository's **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/(root)`, then save.
6. Wait a few minutes and visit `https://YOUR-GITHUB-USERNAME.github.io`.

GitHub's interface can change; if the labels differ, consult https://docs.github.com/pages.

## 4. Add your existing projects to GitHub
Create a separate repository for each project. Include a README that explains:
- What the project does
- Which technologies it uses
- How to run it
- What you personally implemented
- Screenshots or a demo link, if available

Never upload passwords, API keys, private data, or confidential work files.

## Important
This is a starter template. Project cards and the GitHub username are placeholders until you replace them with your own details. Do not claim a project is completed or deployed unless it really is.
